import { COOKIE_NAME } from "../shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { getCustomerByEmail, getMapHistoryById, getMapHistoryByCustomerId, deleteMapHistory } from "./db";
import { TRPCError } from "@trpc/server";
import { customers, pagSeguroOrders } from "../drizzle/schema";
import { getDb } from "./db";
import { eq } from "drizzle-orm";

// Helper to check if user is admin
const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  const adminUser = await db.getAdminByEmail(ctx.user?.email || '');
  if (!adminUser) {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
  }
  return next({ ctx: { ...ctx, admin: adminUser } });
});

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    login: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string().min(6)
      }))
      .mutation(async ({ input, ctx }) => {
        // Get customer by email
        const customer = await db.getCustomerByEmail(input.email);
        if (!customer || !customer.password) {
          throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Credenciais inválidas' });
        }

        // Compare password
        const isValid = await db.comparePassword(input.password, customer.password);
        if (!isValid) {
          throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Credenciais inválidas' });
        }

        // Create session (TODO: implement session management)
        // For now, return success
        return { success: true, customer: { id: customer.id, email: customer.email, name: customer.name } };
      }),
  }),

  /**
   * Customer Management Routes
   */
  customers: router({
    // Get customer by email
    getByEmail: publicProcedure
      .input(z.object({ email: z.string().email() }))
      .query(async ({ input }) => {
        return await db.getCustomerByEmail(input.email);
      }),

    // Create new customer
    create: publicProcedure
      .input(z.object({
        email: z.string().email(),
        name: z.string().min(1),
        plan: z.enum(['basic', 'professional', 'premium']).default('basic'),
        paymentMethod: z.string().optional(),
        paymentId: z.string().optional(),
        amount: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const existing = await db.getCustomerByEmail(input.email);
        if (existing) {
          throw new TRPCError({ code: 'CONFLICT', message: 'Customer already exists' });
        }
        return await db.createCustomer({
          email: input.email,
          name: input.name,
          plan: input.plan,
          status: 'pending',
          paymentMethod: input.paymentMethod,
          paymentId: input.paymentId,
          amount: input.amount,
        });
      }),

    // Update customer status (admin only)
    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(['pending', 'approved', 'rejected']),
      }))
      .mutation(async ({ input }) => {
        return await db.updateCustomer(input.id, {
          status: input.status as 'pending' | 'approved' | 'rejected',
          approvedAt: input.status === 'approved' ? new Date() : undefined,
        });
      }),

    // Get all customers (admin only)
    getAll: adminProcedure.query(async () => {
      return await db.getAllCustomers();
    }),

    // Get customers by status (admin only)
    getByStatus: adminProcedure
      .input(z.object({ status: z.enum(['pending', 'approved', 'rejected']) }))
      .query(async ({ input }) => {
        return await db.getCustomersByStatus(input.status);
      }),
  }),

  /**
   * Numerology Maps Routes
   */
  numerologyMaps: router({
    // Create new map
    create: protectedProcedure
      .input(z.object({
        customerId: z.number(),
        name: z.string().min(1),
        birthDate: z.string(),
        chartData: z.record(z.string(), z.any()),
      }))
      .mutation(async ({ input, ctx }) => {
        const customer = await db.getCustomerByEmail(ctx.user?.email || '');
        if (!customer || customer.id !== input.customerId) {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Cannot create map for other customer' });
        }

        return await db.createNumerologyMap({
          customerId: input.customerId,
          email: ctx.user?.email || '',
          name: input.name,
          birthDate: input.birthDate,
          chartData: input.chartData,
        });
      }),

    // Get maps by customer email
    getByEmail: protectedProcedure
      .input(z.object({ email: z.string().email() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.email !== input.email) {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Cannot access other customer maps' });
        }
        return await db.getNumerologyMapsByEmail(input.email);
      }),

    // Get maps by customer ID (admin only)
    getByCustomerId: adminProcedure
      .input(z.object({ customerId: z.number() }))
      .query(async ({ input }) => {
        return await db.getNumerologyMapsByCustomerId(input.customerId);
      }),
  }),

  /**
   * Admin Management Routes
   */
  admins: router({
    // Check if current user is admin
    isAdmin: protectedProcedure.query(async ({ ctx }) => {
      const adminUser = await db.getAdminByEmail(ctx.user?.email || '');
      return {
        isAdmin: !!adminUser,
        admin: adminUser || null,
      };
    }),

    // Get all admins (admin only)
    getAll: adminProcedure.query(async () => {
      return await db.getAllAdmins();
    }),

    // Create new admin (super admin only)
    create: adminProcedure
      .input(z.object({
        email: z.string().email(),
        name: z.string().min(1),
        role: z.enum(['admin', 'super_admin']).default('admin'),
      }))
      .mutation(async ({ input, ctx }) => {
        const currentAdmin = await db.getAdminByEmail(ctx.user?.email || '');
        if (currentAdmin?.role !== 'super_admin') {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Only super admins can create admins' });
        }

        const existing = await db.getAdminByEmail(input.email);
        if (existing) {
          throw new TRPCError({ code: 'CONFLICT', message: 'Admin already exists' });
        }

        return await db.createAdmin({
          email: input.email,
          name: input.name,
          role: input.role,
          isActive: true,
          createdBy: ctx.user?.email,
        });
      }),

    // Update admin (super admin only)
    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const currentAdmin = await db.getAdminByEmail(ctx.user?.email || '');
        if (currentAdmin?.role !== 'super_admin') {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Only super admins can update admins' });
        }

        return await db.updateAdmin(input.id, {
          name: input.name,
          isActive: input.isActive,
        });
      }),
  }),

  /**
   * Coupon Management Routes
   */
  coupons: router({
    // Get coupon by code
    getByCode: publicProcedure
      .input(z.object({ code: z.string() }))
      .query(async ({ input }) => {
        return await db.getCouponByCode(input.code);
      }),

    // Get all coupons (admin only)
    getAll: adminProcedure.query(async () => {
      return await db.getAllCoupons();
    }),

    // Create coupon (admin only)
    create: adminProcedure
      .input(z.object({
        code: z.string().min(1),
        discountPercentage: z.number().min(0).max(100),
        maxUses: z.number().optional(),
        expiresAt: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createCoupon({
          code: input.code,
          discountPercentage: input.discountPercentage,
          maxUses: input.maxUses,
          expiresAt: input.expiresAt ? new Date(input.expiresAt) : undefined,
          isActive: true,
          createdBy: ctx.user?.email,
        });
      }),

    // Update coupon (admin only)
    update: adminProcedure
      .input(z.object({
        id: z.number(),
        isActive: z.boolean().optional(),
        maxUses: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.updateCoupon(input.id, {
          isActive: input.isActive,
          maxUses: input.maxUses,
        });
      }),
  }),

  /**
   * Payment History Routes
   */
  payments: router({
    // Get payment history by customer ID
    getByCustomerId: protectedProcedure
      .input(z.object({ customerId: z.number() }))
      .query(async ({ input, ctx }) => {
        const customer = await db.getCustomerByEmail(ctx.user?.email || '');
        if (!customer || customer.id !== input.customerId) {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Cannot access other customer payments' });
        }
        return await db.getPaymentHistoryByCustomerId(input.customerId);
      }),

    // Get all payments (admin only)
    getAll: adminProcedure.query(async () => {
      return await db.getAllPaymentHistory();
    }),

    // Create payment record
    create: publicProcedure
      .input(z.object({
        customerId: z.number(),
        email: z.string().email(),
        plan: z.enum(['basic', 'professional', 'premium']),
        amount: z.string(),
        paymentMethod: z.string(),
        paymentId: z.string().optional(),
        couponCode: z.string().optional(),
        discountAmount: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createPaymentHistory({
          customerId: input.customerId,
          email: input.email,
          plan: input.plan,
          amount: input.amount,
          currency: 'BRL',
          status: 'pending',
          paymentMethod: input.paymentMethod,
          paymentId: input.paymentId,
          couponCode: input.couponCode,
          discountAmount: input.discountAmount,
        });
      }),

    // Update payment status (admin only)
    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(['pending', 'completed', 'failed']),
      }))
      .mutation(async ({ input }) => {
        return await db.updatePaymentHistory(input.id, {
          status: input.status as 'pending' | 'completed' | 'failed',
          completedAt: input.status === 'completed' ? new Date() : undefined,
        });
      }),
  }),

  /**
   * Reports Routes
   */
  reports: router({
    // Get all reports (admin only)
    getAll: adminProcedure.query(async () => {
      return await db.getAllReports();
    }),

    // Get reports by type (admin only)
    getByType: adminProcedure
      .input(z.object({ type: z.string() }))
      .query(async ({ input }) => {
        return await db.getReportsByType(input.type);
      }),

    // Create report (admin only)
    create: adminProcedure
      .input(z.object({
        title: z.string().min(1),
        type: z.string().min(1),
        data: z.record(z.string(), z.any()),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createReport({
          title: input.title,
          type: input.type,
          data: input.data,
          generatedBy: ctx.user?.email,
        });
      }),
  }),
  /**
   * Renascimento Management Routes
   */
  renascimento: router({
    // Get Renascimento by customer ID (admin only)
    getByCustomerId: adminProcedure
      .input(z.object({ customerId: z.number() }))
      .query(async ({ input }) => {
        return await db.getRenascimentoByCustomerId(input.customerId);
      }),

    // Get Renascimento by email (admin only)
    getByEmail: adminProcedure
      .input(z.object({ email: z.string().email() }))
      .query(async ({ input }) => {
        return await db.getRenascimentoByEmail(input.email);
      }),

    // Create or update Renascimento (admin only)
    upsert: adminProcedure
      .input(z.object({
        customerId: z.number(),
        email: z.string().email(),
        hasFactoGrave: z.boolean(),
        factoGraveType: z.enum(['enfermidade', 'acidente', 'perda_material', 'perda_afetiva']).optional(),
        notes: z.string().optional(),
        realizacao: z.number().optional(),
        realizacaoNumber: z.number().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const existing = await db.getRenascimentoByCustomerId(input.customerId);
        
        if (existing) {
          return await db.updateRenascimento(input.customerId, {
            hasFactoGrave: input.hasFactoGrave,
            factoGraveType: input.factoGraveType,
            notes: input.notes,
            realizacao: input.realizacao,
            realizacaoNumber: input.realizacaoNumber,
            updatedBy: ctx.user?.email ?? undefined,
          });
        } else {
          return await db.createRenascimento({
            customerId: input.customerId,
            email: input.email,
            hasFactoGrave: input.hasFactoGrave,
            factoGraveType: input.factoGraveType,
            notes: input.notes,
            realizacao: input.realizacao,
            realizacaoNumber: input.realizacaoNumber,
            updatedBy: ctx.user?.email ?? undefined,
          });
        }
      }),

    // Get all Renascimentos (admin only)
    getAll: adminProcedure.query(async () => {
      return await db.getAllRenascimentos();
    }),

    // Delete Renascimento (admin only)
    delete: adminProcedure
      .input(z.object({ customerId: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteRenascimento(input.customerId);
        return { success: true };
      }),
  }),

  /**
   * Payment Router - PagSeguro Integration
   */
  payment: router({
    // Initiate payment with PagSeguro
    initiatePagSeguro: publicProcedure
      .input(z.object({
        email: z.string().email(),
        name: z.string().min(1),
        password: z.string().min(6).optional(),
        planId: z.enum(['navigator', 'visionary', 'illuminated']),
        planName: z.string(),
        amount: z.number().positive(),
        paymentMethod: z.enum(['pix', 'credit_card', 'boleto']),
        address: z.object({
          cep: z.string(),
          street: z.string(),
          number: z.string(),
          complement: z.string().optional(),
          neighborhood: z.string(),
          city: z.string(),
          state: z.string(),
        }).optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          if (!getDb) {
            throw new TRPCError({
              code: 'INTERNAL_SERVER_ERROR',
              message: 'Database connection failed'
            });
          }
          
          const { createPaymentOrder: createPaymentOrderFn } = await import('./pagseguro');
          const { createCustomer: createCustomerFn, getCustomerByEmail: getCustomerByEmailFn } = await import('./db');
          const { sendPaymentConfirmationEmail } = await import('./email/emailService');
          
          // 1. Save or update customer in database with password and address
          const existingCustomer = await getCustomerByEmailFn(input.email);
          const { hashPassword } = await import('./db');
          
          let customerId: number;
          if (existingCustomer) {
            customerId = existingCustomer.id;
            // Update password if provided
            if (input.password && !existingCustomer.password) {
              const hashedPassword = await hashPassword(input.password);
              const database = await getDb();
              if (database) {
                await database.update(customers)
                  .set({ 
                    password: hashedPassword
                  })
                  .where(eq(customers.id, existingCustomer.id));
              }
            }
          } else {
            // Create new customer with hashed password if provided
            const hashedPassword = input.password ? await hashPassword(input.password) : null;
            const newCustomer = await createCustomerFn({
              email: input.email,
              name: input.name,
              password: hashedPassword,
              plan: 'pending',
              status: 'pending'
            });
            customerId = newCustomer?.id || 0;
          }
          
          // 2. Create payment order with PagSeguro
          const paymentResponse = await createPaymentOrderFn({
            email: input.email,
            name: input.name,
            planId: input.planId,
            planName: input.planName,
            amount: input.amount,
            paymentMethod: input.paymentMethod as 'pix' | 'credit_card' | 'boleto',
          });
          
          // 3. Save order in database with status 'pending'
          const { createPagSeguroOrder: createPagSeguroOrderFn } = await import('./db');
          await createPagSeguroOrderFn({
            orderId: paymentResponse.id,
            email: input.email,
            name: input.name,
            plan: input.planId,
            amount: input.amount.toString(),
            paymentMethod: input.paymentMethod,
            status: 'pending',
            pagseguroReference: paymentResponse.id,
            pagseguroCode: paymentResponse.id,
            pagseguroStatus: paymentResponse.status,
          });
          
          // 4. Send "payment processing" email
          await sendPaymentConfirmationEmail({
            email: input.email,
            planType: input.planName,
            mapsLimit: 10, // Default limit, will be updated based on plan
            accessLink: `${process.env.APP_URL || 'https://guia-numerologia.manus.space'}/dashboard`,
            orderId: paymentResponse.id,
          });
          
          // Extract payment link from response
          // PagSeguro returns payment link in different formats depending on payment method
          let paymentLink = '';
          
          if (paymentResponse.links && Array.isArray(paymentResponse.links)) {
            const paymentLinkObj = paymentResponse.links.find(
              (link: any) => link.rel === 'PAYMENT' || link.rel === 'payment'
            );
            paymentLink = paymentLinkObj?.href || '';
          }
          
          // If no link found, construct it from order ID
          if (!paymentLink && paymentResponse.id) {
            paymentLink = `https://checkout.pagseguro.com/checkout/payment/${paymentResponse.id}`;
          }
          
          if (!paymentLink) {
            console.warn('No payment link found in PagSeguro response:', paymentResponse);
            throw new TRPCError({
              code: 'INTERNAL_SERVER_ERROR',
              message: 'Não foi possível gerar o link de pagamento'
            });
          }
          
          return {
            success: true,
            orderId: paymentResponse.id,
            paymentLink: paymentLink,
            status: paymentResponse.status,
          };
        } catch (error) {
          console.error('Error initiating PagSeguro payment:', error);
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Failed to initiate payment',
          });
        }
      }),

    // Get payment status
    getStatus: publicProcedure
      .input(z.object({ orderId: z.string() }))
      .query(async ({ input }) => {
        try {
          const { getPaymentStatus } = await import('./pagseguro');
          const status = await getPaymentStatus(input.orderId);
          return status;
        } catch (error) {
          console.error('Error fetching payment status:', error);
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Failed to fetch payment status',
          });
        }
      }),
  }),

  /**
   * Order History Router - PagSeguro Orders
   */
  orders: router({
    // Get order history by email (protected)
    getByEmail: protectedProcedure
      .query(async ({ ctx }) => {
        if (!ctx.user?.email) {
          throw new TRPCError({ code: 'UNAUTHORIZED' });
        }
        return await db.getOrdersByEmail(ctx.user.email);
      }),

    // Get single order by ID (protected)
    getById: protectedProcedure
      .input(z.object({ orderId: z.string() }))
      .query(async ({ input, ctx }) => {
        if (!ctx.user?.email) {
          throw new TRPCError({ code: 'UNAUTHORIZED' });
        }
        const order = await db.getOrderById(input.orderId);
        if (!order || order.email !== ctx.user.email) {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        return order;
      }),

    // Get all orders (admin only)
    getAll: adminProcedure.query(async () => {
      return await db.getAllPagSeguroOrders();
    }),
  }),

  /**
   * Map History Router
   */
  mapHistory: {
    getMyMaps: protectedProcedure
      .query(async ({ ctx }) => {
        if (!ctx.user?.email) {
          throw new TRPCError({ code: 'UNAUTHORIZED' });
        }
        
        // Get customer by email
        const customer = await getCustomerByEmail(ctx.user.email);
        if (!customer) {
          return [];
        }
        
        // Get map history
        const maps = await getMapHistoryByCustomerId(customer.id);
        return maps;
      }),

    getMapById: protectedProcedure
      .input(z.object({ mapId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (!ctx.user?.email) {
          throw new TRPCError({ code: 'UNAUTHORIZED' });
        }
        
        const map = await getMapHistoryById(input.mapId);
        if (!map) {
          throw new TRPCError({ code: 'NOT_FOUND' });
        }
        
        // Verify ownership
        const customer = await getCustomerByEmail(ctx.user.email);
        if (!customer || map.customerId !== customer.id) {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        
        return map;
      }),

    deleteMap: protectedProcedure
      .input(z.object({ mapId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user?.email) {
          throw new TRPCError({ code: 'UNAUTHORIZED' });
        }
        
        const map = await getMapHistoryById(input.mapId);
        if (!map) {
          throw new TRPCError({ code: 'NOT_FOUND' });
        }
        
        // Verify ownership
        const customer = await getCustomerByEmail(ctx.user.email);
        if (!customer || map.customerId !== customer.id) {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        
        await deleteMapHistory(input.mapId);
        return { success: true };
      }),
  },

  /**
   * Password Reset Router
   */
  passwordReset: router({
    // Request password reset
    request: publicProcedure
      .input(z.object({ email: z.string().email() }))
      .mutation(async ({ input }) => {
        const bcrypt = await import('bcrypt');
        const crypto = await import('crypto');
        
        // Check if customer exists
        const customer = await db.getCustomerByEmail(input.email);
        if (!customer) {
          // Don't reveal if email exists or not for security
          return { success: true, message: 'Se o email existir, você receberá um link de redefinição' };
        }
        
        // Generate reset token
        const token = crypto.randomBytes(32).toString('hex');
        const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour
        
        // Save token to database
        await db.createPasswordResetToken({
          email: input.email,
          token,
          expiresAt,
        });
        
        // Send email with reset link
        const resetLink = `${process.env.APP_URL || 'http://localhost:3000'}/reset-password?token=${token}`;
        
        try {
          const { sendPasswordResetEmail } = await import('./email/emailService');
          await sendPasswordResetEmail(input.email, customer.name, resetLink);
        } catch (error) {
          console.error('Error sending password reset email:', error);
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Erro ao enviar email de redefinição',
          });
        }
        
        return { success: true, message: 'Email de redefinição enviado com sucesso' };
      }),

    // Validate reset token
    validateToken: publicProcedure
      .input(z.object({ token: z.string() }))
      .query(async ({ input }) => {
        const tokenData = await db.getPasswordResetToken(input.token);
        
        if (!tokenData) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Token inválido',
          });
        }
        
        if (tokenData.used) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Token já foi utilizado',
          });
        }
        
        if (new Date() > new Date(tokenData.expiresAt)) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Token expirado',
          });
        }
        
        return { valid: true, email: tokenData.email };
      }),

    // Reset password
    reset: publicProcedure
      .input(z.object({
        token: z.string(),
        newPassword: z.string().min(6),
      }))
      .mutation(async ({ input }) => {
        const bcrypt = await import('bcrypt');
        
        // Validate token
        const tokenData = await db.getPasswordResetToken(input.token);
        
        if (!tokenData) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Token inválido',
          });
        }
        
        if (tokenData.used) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Token já foi utilizado',
          });
        }
        
        if (new Date() > new Date(tokenData.expiresAt)) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Token expirado',
          });
        }
        
        // Hash new password
        const hashedPassword = await bcrypt.hash(input.newPassword, 10);
        
        // Update customer password
        await db.updateCustomerPassword(tokenData.email, hashedPassword);
        
        // Mark token as used
        await db.markPasswordResetTokenAsUsed(input.token);
        
        return { success: true, message: 'Senha redefinida com sucesso' };
      }),
  }),

});

export type AppRouter = typeof appRouter;

// Subscription and Payment Procedures are added below
// This will be integrated in the next update
